<?php session_start(); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="theme-color" content="#005D4B">
  <link rel="stylesheet" href="../stylef.css" />
  <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php include("../../template/header.php"); ?>
<?php include("../../template/menu.php"); ?>

<section id="fenetre"> <!-- bordure et fond couleur diff -->

  <article class="note">
    <h3>Titre a la con</h3>
    <p>
    Au clilc sur ajout note, apparait ici une technote vide, avec une barre d'outils
    wiziwig en vert degradé sous le titre .<br>
    options: gras, titre, code source
    </p>

  </article >
  <article class="note">
    <h3>Titre a la con</h3>
    <p>
      Ici il y aura un bouton en bas a gauche pour derouler les
      commentaires dans un ton vert clair.
    </p>
    <p>
      Lorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la con
    </p>
  </article>
  <article class="note">
    <h3>Titre a la con</h3>
    <p> un lorem plus long ipsum beaucoup plus long un lorem plus long ipsum beaucoup plus long un lorem plus long ipsum beaucoup plus longun lorem plus long ipsum beaucoup plus longun lorem plus long ipsum beaucoup plus long un lorem plus long ipsum beaucoup plus long un lorem plus long ipsum beaucoup plus long un lorem plus long ipsum beaucoup plus long un lorem plus long ipsum beaucoup plus longun lorem plus long ipsum beaucoup plus longun lorem plus long ipsum beaucoup plus longv
      Lorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la conLorem texte ipsum a la con
    </p>
  </article>


</section>
<?php include("template/footer.php"); ?>
</body>
</html>
