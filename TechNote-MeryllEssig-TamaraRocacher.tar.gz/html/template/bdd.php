<?php
if(!isset($bdd)) {
  $bdd = new PDO('mysql:host=localhost;dbname=Technote', 'root', 'theo030911');
}
?>
