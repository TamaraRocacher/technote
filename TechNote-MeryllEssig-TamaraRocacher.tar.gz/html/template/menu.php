<nav id="menu">
<a href="../question.php"><img id="boutonF" src="../img/32.png" /> </a>
<form action="../../../search/search.php" method="get" id="rech">
	<input class="search" type="text" name="search" placeholder="Recherche par mot-clé, @personne ou j:jj m:mm a:aaaa"/>
  <input class="loupe" type="image" src="../img/glass.png" onclick="this.form.submit();" />
</form>
<a href="add.php"><button class="ajout">+</button></a>
</nav>
