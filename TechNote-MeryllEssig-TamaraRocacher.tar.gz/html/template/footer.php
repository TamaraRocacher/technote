<footer>
  <p>Propulsé par Meryll et Tamara.</p>
</footer>
